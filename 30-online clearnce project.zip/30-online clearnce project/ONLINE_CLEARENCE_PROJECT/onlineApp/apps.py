from django.apps import AppConfig


class OnlineappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'onlineApp'
