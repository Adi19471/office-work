from django.apps import AppConfig


class TechniquesappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Techniquesapp'
