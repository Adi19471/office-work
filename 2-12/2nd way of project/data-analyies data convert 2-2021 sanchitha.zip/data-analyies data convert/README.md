data analysies convert to the backend data how process bussiness and modeling convert the data 


before you have to install 
pip install matlob 
            pandas
            \
            \
            \
            \
            \
            \
            \
            \
            \

            alll the file showing indicate when run the program you have to install all 3rd party libraryies