from django.contrib import admin

# Register your models here.
from.models import Assignments,Employe

# admin.site.register(Assignments)

@admin.register(Assignments)
class Assignments(admin.ModelAdmin):
    list_display = ['id','name_of_title','downlode_attachement','status','detail']

admin.site.register(Employe)



