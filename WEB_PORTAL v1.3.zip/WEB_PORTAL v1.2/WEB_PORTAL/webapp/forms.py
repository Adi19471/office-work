from django import forms

from .models import Assignments


class AssignmentsForms(forms.ModelForm):
    class Meta:
        model = Assignments
        fields = "__all__"

        labels = {
            "assign_id",
            "emp_id",
            "name_of_title",
            "create_date",
            "date_of_assigning_task",
            "date_of_submistion",
            "call_to_people",
            "assigned_to",
            "skill_required",
            "uplode_attachement",
        }

        labels = {
            "assign_id": "assigning Number",
            "emp_id": "Employe Id",
            "name_of_title": "Name Of Title",
            "create_date": "Create Date",
            "date_of_assigning_task": "Assigning Task",
            "date_of_submistion": "Submition on Date",
            "call_to_people": "Assigning To Employe",
            "assigned_to": "Assigning_work",
            "skill_required": "Skills Required",
            "uplode_attachement": "Uplode File",
        }

        widgets = {
            "assign_id": forms.NumberInput(attrs={"class": "form-control"}),
            "emp_id": forms.TextInput(attrs={"class": "form-control"}),
            "name_of_title": forms.TextInput(
                attrs={
                    "class": "form-control",
                }
            ),
            "create_date": forms.DateInput(attrs={"class": "form-control"}),
            "date_of_assigning_task": forms.DateTimeInput(
                attrs={"class": "form-control"}
            ),
            "date_of_submistion": forms.DateTimeInput(attrs={"class": "form-control"}),
            "call_to_people": forms.TextInput(
                attrs={"class": "form-control",}
            ),
            "assigned_to": forms.TextInput(
                attrs={"class": "form-control"}
            ),
            "skill_required": forms.TextInput(
                attrs={
                    "class": "form-control",
                }
            ),
            "uplode_attachement": forms.FileInput(attrs={"class": "form-control"}),
        }
