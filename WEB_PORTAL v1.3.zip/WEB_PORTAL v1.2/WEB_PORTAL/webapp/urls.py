from django.urls import path
from webapp import views 

urlpatterns = [
    path('',views.home_view,name="home"),
    path('about-detailes/',views.about_view,name="about"),
    path('webportal-detailes/',views.webportal_view,name="webportal"),

 

    path('task-detailes',views.Task_view,name="task"),
    # path('',views.home_view,name="home"),

    path('assignment-detailes/',views.assignment_view,name="create-data"),

    path('show-assignment/',views.showassignment_view,name='showdata'),



]
