from django.contrib import admin

# Register your models here.
from.models import Assignments,Employe

# admin.site.register(Assignments)
@admin.register(Assignments)
class AssignmentsAdmin(admin.ModelAdmin):
    list_display = ['assign_id','emp_id','name_of_title',
    'create_date','date_of_assigning_task','date_of_submistion',
    'call_to_people','assigned_to','skill_required','uplode_attachement']

admin.site.register(Employe)

    