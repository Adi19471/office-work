from typing import Optional
from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Assignments(models.Model):
  
    assign_id                = models.AutoField(primary_key=True)
    emp_id                   = models.CharField(max_length=40 )
    name_of_title            = models.CharField(max_length=50)
    create_date              = models.DateField(auto_now_add=True)
    date_of_assigning_task   = models.DateTimeField(auto_now=True)
    date_of_submistion       = models.DateField(auto_now=False)
    call_to_people          = models.CharField(max_length=200)
    assigned_to             = models.CharField(max_length=120,default=None)
    skill_required          = models.CharField(max_length=120,default="Optional")
    uplode_attachement      = models.FileField(upload_to="files/",default="Optional")
   

    def __str__(self):
       return self.name_of_title
    

class Employe(models.Model):
    # EMPSKILLS_CHOICES = (
    #     ['ui','ui'],
    #     ['html','html'],
    #     ['css','css'],
    #     ['python','python'],
    #     ['djagno','django'],

    # )
    
    empid = models.CharField(max_length=6)
    empname = models.OneToOneField(Assignments,on_delete=models.CASCADE)
    empskills = models.CharField(max_length=120,)

    def __str__(self):
       return self.empname


  
   

    