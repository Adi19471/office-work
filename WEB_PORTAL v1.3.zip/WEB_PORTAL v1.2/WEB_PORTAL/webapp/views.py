from django.http.response import HttpResponse
from django.shortcuts import redirect, render

from django.contrib import messages

from.models import Assignments
from.forms import AssignmentsForms



# Create your views here.
def home_view(request):
    return render(request,'web/home.html')


def about_view(request):
    return render(request,'web/about.html')


def webportal_view(request):
    return render(request,'web/webportal.html')


# assgning data create view
def assignment_view(request):
    if request.method=="POST":
        fm = AssignmentsForms(request.POST)
        if fm.is_valid():
            # a1 = fm.cleaned_data['assign_id']
            a2 = fm.cleaned_data['emp_id']
            a3 = fm.cleaned_data['name_of_title']
            # a4 = fm.cleaned_data['create_date']
            # a5 = fm.cleaned_data['date_of_assigning_task']
            a6 = fm.cleaned_data['date_of_submistion']
            a7 = fm.cleaned_data['call_to_people']
            a8 = fm.cleaned_data['assigned_to']
            a9 = fm.cleaned_data['skill_required']
            a10 = fm.cleaned_data['uplode_attachement']

            data = Assignments(emp_id=a2,name_of_title=a3,
            date_of_submistion=a6,call_to_people=a7,assigned_to=a8,
            skill_required=a9,uplode_attachement=a10
           )
            
            data.save()    
    else:
        fm = AssignmentsForms()

    context = {"form":fm,}
    return render(request,'web/assignment.html',context)



# show assignment web page 

def showassignment_view(request):
    assignment_all = Assignments.objects.all()  
    context = {'assignment_all':assignment_all}
    return render(request,'web/showassignment.html',context)



def Task_view(request):
    return render(request,'web/Task.html')


